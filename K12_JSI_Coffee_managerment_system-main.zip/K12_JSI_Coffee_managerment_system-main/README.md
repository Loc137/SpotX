Create account at https://cloudinary.com
Find cloud name, api key and api secret inside the dashboard and add to .env inside server folder
