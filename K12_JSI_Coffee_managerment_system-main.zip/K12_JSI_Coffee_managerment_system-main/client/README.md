Changes are inside ./src/js/admin.js
Please edit http://localhost:3000/upload with a deployed version